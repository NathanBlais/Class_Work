#include <stdio.h>

int main ( ) {
    int n;
    n = 48;
    printf ("%c\n", n);
    return 0;
}
