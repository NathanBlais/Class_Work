#include <stdio.h>
//made by Nathan Blais
int main()
{
printf("Welcome to CSE 31!\n");
return 0; 
}
